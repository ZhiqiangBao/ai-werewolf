# 配音质量检查与定点修复

本流程只用于上帝视角；单玩家视角暂不支持 `--repair-audio`。玩家版片段出现问题时，保留旧项目和产物，在新项目目录重新制作，不要把修复文件放回旧项目。

这套工具直接计算音频特征，不依赖手工填写异常片段名单。Node/tsx 即可运行，无需另装分析库。检查、重配、重建成片分开保留报告，方便恢复。

## 自动流程

```powershell
pnpm video:make --room=ID --repair-audio --resume
```

默认工作流在 TTS 后自动执行 `audit-audio`。没有 `--repair-audio` 时，发现异常便停止，报告保存在 `output/audio-audit.json` 和同名 Markdown。已授权的服务与范围内使用该参数，程序只重配失败片段，复查通过后继续时间轴和画面。`timeline.ts`、整片与样品验证器也会拒绝未处理的波形缺陷，防止手动分阶段运行时漏检。

## 独立检查与修复已有视频

先固定本局目录，避免检查错误房间：

```powershell
$env:VIDEO_ROOM = '实际房间ID'
# 使用独立版本目录时再显式设置 VIDEO_PROJECT_DIR。
pnpm video:audit-audio --report=output/audio-audit-before.json
pnpm video:repair-audio --auto --audit=output/audio-audit-before.json --rebuild
```

- `audit-audio.ts` 扫描 `clips.json` 的全部原始 WAV，检查 PCM、原稿及真实字词时间。报告记录异常类型、源片段、文件摘要和成片位置；附带短 WAV 供试听。`--fail-on-error` 适合质量门禁；`--no-excerpts` 只生成报告。
- `repair-audio.ts --auto` 从检测报告选择失败片段。人听到工具尚未覆盖的异常时可用 `--clips=134-1,144-1` 显式选段；这只是工具用法示例，不是其他房间的异常名单。过期报告、其他房间或目录不匹配会在外发前被拒绝。
- 新配音沿用原文、模型、固定音色、指令和语速，仅改变 Qwen 的随机种子以生成新一版。默认种子仍为 31415，旧缓存键保持不变；成功的新种子写进本局 `voices.json` 的 `clipSeeds`，以后恢复不会换回旧的坏缓存。其他提供方需要显式实现重新生成能力，工具不会换服务或计费线路。
- 每个片段默认最多试三次，可用 `--max-attempts=1..5` 调整。候选必须通过波形、原话、声线、文件完整性及字词时间检查，才替换原文件。鉴权、额度、429 或本地文件写入失败时停止，不无限重试。
- 原 WAV、元数据与声音设置备份在 `audio-repairs/运行编号/片段编号/`；失败候选也保留。自动重配只修改选中的音频及对应请求设置，不改对局事实或玩家观点。
- `--rebuild` 依次重建时间轴、画面、预览并验证整片。首次重建前将旧视频保存在 `output/latest-match-before-audio-repair.mp4`。新音频长短变化会使后续字幕与技能滚动位置变化，程序按缓存键更新需要重做的画面，不直接把不同长度的声音塞进旧时间轴。

成功后检查 `output/audio-audit-after.json` 与 `output/audio-repair-report.json`，并交付新的 `output/latest-match.mp4`。标题和简介仍保存在 `output/publish-copy.md`。不能只替换 WAV 而不重建成片。

## 检测依据与边界

真实复查发现过约 0.5～0.7 秒的近满幅负值平段：波形长时间停在 -32767／-32768，正常说话信号已经损坏。归一化只会降低它的幅度，不能恢复语音。因此检测器检查原始 PCM，并识别归一化后仍然存在的非零平段。

当前 `pcm-integrity-v1` 检测：

1. **非零平段**：采样值在 8 LSB 容差内持续至少 20 毫秒，幅度至少满幅的 5%。忽略普通静音；降低音量后的损坏仍可识别。
2. **削波**：同极性近满幅平台持续至少 3 毫秒，或反复出现较短平台。单独一两个采样点触顶不会直接判为破音；连续的削波周期合并成一个报告区间。
3. **近乎静音**：整段能量和峰值都极低。原始 WAV 的流式长度声明按实际 PCM 读取，不把 Qwen 的流式头误当成破音。

这些是可重复的信号检查，不能保证识别所有听感、发音或语义问题。用户指出其他异常时，核对片段与波形，保留正常对照，用发现的实际特征扩展检测器和测试；不要把某个房间的片段编号硬编码为检测规则。不能只凭检查通过就声称自己听过音频。

当前自动化保留 [玩家视角视频完整合成流程](../../../packages/session/test/player-video.test.ts)，使用合成配音验证产物与缓存篡改检查；原始波形和实际听感仍需按本指南核对，不因此宣称所有音频缺陷都已覆盖。

## narration.json 中的受限分段与读音选项

需要机械拆分长玩家发言或修正英语所有格读音时，可在项目 narration.json 顶层（与 roomId、edits 同级）按需添加以下字段；不要把它们写进 edits：

~~~~json
{
  "roomId": "本局 ID",
  "edits": {},
  "speechParts": {
    "40": ["<原始玩家发言的连续第一段>", "<同一发言的连续第二段>"]
  },
  "englishPossessiveClips": ["040-1"]
}
~~~~

- speechParts 是 sourceSeq 到字符串数组的映射，仅用于上帝视角的原始玩家发言机械分段；key 必须是该发言有效的 sourceSeq，其他来源会被拒绝。每段必须非空且最多 600 个字符；按顺序拼接各段、忽略所有空白后，必须与原始发言逐字相同（同样忽略空白）。不可增删、换序或改写玩家用词。
- englishPossessiveClips 是 narration 顶层的 clip ID 列表，仅用于上帝视角、英语对局中指定的原始玩家发言片段。示例中的 40、040-1 和原话占位内容都要替换成本局实际值。它只改生成的朗读文本，不改原始 entry：无前导零的独立 0–99 数字所有格按英文读数展开，例如 5's 变成 five's；词尾为 s 的复数所有格去掉末尾撇号，例如 wolves' 读作 wolves；it's 保持不变。无适用转换的 ID、未知或重复 ID、非英语或玩家视角都会被拒绝。
- 这两项仅授权上述机械处理，不是任意调整玩家原话的许可。speechParts 可能改变 clips.json 中的分段、clip ID 和相应缓存路径；任何变更前，备份 narration.json、clips.json，以及受影响片段的 WAV、同名 JSON 元数据和 .alignment.json sidecar。新音频产生后，旧 sidecar 若仍绑定旧音频就不能沿用；保留备份，将旧 sidecar 移出活动文件名，再按当前音频重新核验。其他成功音频缓存不要改动或清空。

修改后先在仓库根目录运行：
~~~~powershell
pnpm video:make --room=ROOM_ID --check-only
~~~~

确认 output/materials-check.json 中 ready 为 true。该步骤停在配音前检查，不调用 TTS；报告未就绪时按 issues 修正并再次检查。

只有 TTS 服务调用已获授权后，再让视频流程处理变化片段：
~~~~powershell
pnpm video:make --room=ROOM_ID --resume --through=timeline
~~~~

当前 Qwen TTS 会复用缓存键匹配且 WAV 完整的片段缓存；缓存键包含请求文本、模型和音色参数。输入改变的片段只有在不存在有效匹配缓存时才会重新合成；其他成功音频缓存保持原样。确认 synthesis-status.json 成功，再检查 WAV、同名元数据的实际词时间及 timeline.json 中的字幕边界；不要删除其他成功缓存。若词时不可靠或 sidecar 失效，先取得与当前原音绑定的可靠字时再继续。若要交付更新后的成片，再执行完整工作流：
~~~~powershell
pnpm video:make --room=ROOM_ID --resume
~~~~

重新渲染并验证；不要只替换 WAV。

生成的 narration.json、音频和对齐 sidecar 属于本局制作材料；不要把玩家原话复制到 tracked 文档或公开报告。
