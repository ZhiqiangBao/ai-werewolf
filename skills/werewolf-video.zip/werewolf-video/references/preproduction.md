# 制作前准备与台词润色：从对局到可运行的制作材料

这一步由制作者（AI agent 或真人）完成。`prepare.ts` 只生成素材索引与模板，不会替你完成有表达质量的叙事编辑，也不会自动请求另一个文案模型。不要把“脚本能运行”当作“台词已润色”。先按本文件备齐材料，再开始 TTS 和渲染。

本文件的旁白与全桌画面步骤默认用于完整上帝视角。若制作单玩家历史视角，命令须指定 `--player-seat=N`，改按[单玩家视角制作](player-view.md)执行：只审核该席位可见的历史原话，不写自由解说，并让其他座位身份始终保持未知。两条流程不能共用编辑稿或样品目录。

## 启动前到底准备到哪一步

第一次运行 `--prepare-only` 前，需要已结束房间、项目依赖和可读的存档；此时不必先手工创建旁白文件。脚本会生成下表的初稿与索引。完整上帝视角进入正式配音前，制作者必须完成上帝解说和声音表的实际核对、选择已授权的 TTS 服务与凭据；再运行 `--check-only`。单玩家视角遵照[该视角的审核字段与材料规则](player-view.md)，不能用本页的自由解说模板。

| 文件／事项 | 脚本生成什么 | 开始正式配音前需完成什么 |
| --- | --- | --- |
| `plan.json`、`editorial-context.json` | 房间、身份、规则、事实与发言索引 | 阅读材料，引用发言时补读完整原文 |
| `narration.json` | 可编辑模板，不代表已完成本局解说 | 上帝视角按 [上帝解说写作](commentary.md) 写开场、点评、收尾；玩家视角保留空 `edits` 并按 [单玩家视角制作](player-view.md) 核对授权原话 |
| `voices.json` | 按主题匹配的默认声音配置与座位标签，已有文件保留 | 按[立绘与声线](character-voices.md)核对角色、音色、指令与语速并试听；原始立绘提示词随技能附带，法官和上帝分开 |
| TTS 配置 | 沿用显式选择的适配器和模型 | 确认服务可用、凭据已配置、外发已授权；接入方法见 [批量 TTS](tts-batch.md) |
| 主题与样品选择 | 已有美术；样品需另选节点 | 使用已确认画面，需样品时备好独立选择表 |

封面和最终发布文案可在成片制作期间准备，在最终交付前补齐。`--check-only` 只检查配音启动材料，不宣称封面、试听或文案已经完成。

首次制作或更换工作站时，在仓库根目录先确认 Node.js、pnpm、FFmpeg 与 FFprobe 可用：

```powershell
node --version
pnpm --version
ffmpeg -version
ffprobe -version
```

按项目 `AGENTS.md`／`package.json` 的版本要求安装 Node.js 与 pnpm；当前仓库要求 Node.js 22.12 或更新版本。依赖未安装时运行 `pnpm install`。FFmpeg 与 FFprobe 必须能从 `PATH` 调用；如果已有可执行文件但不在 `PATH`，在同一 PowerShell 会话设置 `$env:FFMPEG_PATH` 和 `$env:FFPROBE_PATH` 为对应绝对路径。缺失工具时先停止并请用户提供安装或可用路径，不要等整局配音后才发现。`--check-only` 不检查这些程序、TTS 凭据或本地 ASR 模型是否就绪。

安装／bootstrap 后、配音前检查美术资源是否已复制到 `apps/web/public/art/moon-village/`：至少要有昼夜背景、昼夜桌面和当前主题头像图集。默认主题为 `campus`，替换 `--theme` 时应核对对应的 `avatars-<theme>-v1.webp`。缺项可按[程序启动与bootstrap](automation.md#运行环境)及技能入口执行 bootstrap，再检查是否出现；不要用缺图开始整局配音。Windows 画面会尝试注册 `C:/Windows/Fonts/msyh.ttc` 与 `msyhbd.ttc`；其他系统按[硬件说明](hardware.md)选择并注册实际中文字体。若字体不存在，先解决字体回退并用短画面检查文字，不能把程序退出成功当成中文字体正确。

准备出本局 `source.json` 后、任何真实 TTS 前，再按本局语言检查工作流实际会使用的工具和凭据。以下只输出可用性布尔值，不显示密钥；使用自定义 `--data-dir` 时，先把 `$env:VIDEO_DATA_DIR` 和 `$env:WEREWOLF_DATA` 设为同一绝对目录：

```powershell
node --import tsx --input-type=module -e "import { execFileSync } from 'node:child_process'; import { ffmpeg, ffprobe } from './scripts/video/project.ts'; import { projectQwenTokenPlanKey } from './packages/session/src/project-models.ts'; await import('@napi-rs/canvas'); for (const bin of [ffmpeg, ffprobe]) execFileSync(bin, ['-version'], { stdio: 'ignore' }); const key = projectQwenTokenPlanKey(); console.log(JSON.stringify({ ffmpeg: true, ffprobe: true, canvas: true, qwenTtsCredential: Boolean((process.env.WEREWOLF_TTS_API_KEY || '').startsWith('sk-sp-') || key), qwenAsrCredential: Boolean(key) }));"
```

`ffmpeg`、`ffprobe` 或 `canvas` 导入失败时，先按上方处理本机依赖。无 TTS 凭据时不要启动会产生外部合成请求的命令；Qwen TTS 可使用 `WEREWOLF_TTS_API_KEY` 或可解密的项目模型库条目。日语 `auto` 或任一语言显式选 Qwen ASR 时，`qwenAsrCredential` 必须为 `true`；ASR 不读取单独的 `WEREWOLF_TTS_API_KEY`。如本局为中文/英语且采用 `auto`，按[音频核对操作指南](local-asr.md)先注册本机模型并确认服务就绪；`--check-only` 不会代替这项检查。缺少服务、凭据或必要授权时先停止，请用户配置或明确授权可用路线，不要暗中换 provider。

## 第一阶段：只运行轻量准备，确认素材

在 `ai-werewolf` 仓库执行：

```powershell
pnpm video:make --room=latest --prepare-only
```

记下输出的实际房间 ID，后续固定用该 ID，避免新结束的对局使 `latest` 改变。已指定房间时用指定 ID。此阶段只读已结束存档并写制作材料，不生成整局配音、不重开游戏。

先读 `data/video/ID/plan.json`，再读其 `editorialContextFile`。后者是程序生成的 `editorial-context.json`，包含本局公共规则、完整身份表、按时间排序的结构化行动/票型、玩家发言索引与终局核对材料。索引只给开头；需要引用或评价某段话时，再按 `sourceSeq` 从 `data/exports/ID-video-script.json` 读取完整原文。

制作前材料清单：

| 材料 | 从哪里来 | 由制作者完成什么 |
| --- | --- | --- |
| 原始剪辑稿和事实 | `video:make --prepare-only` 导出 | 确认房间已结束、导出视角与本次授权相符；不修改事实 |
| `editorial-context.json` | `prepare.ts` 自动生成 | 了解转折、确定点评锚点；不能拿终局信息提前写到过程里 |
| `voices.json` | 默认音色表 + `plan.json` 人设 | 核对每个角色与音色，写好对应表达指令，保持跨昼夜一致 |
| `narration.json` | 自动模板/旧编辑稿 | **亲自润色开场、关键转折和收尾**，按下面的方法写回 |
| ASR 路由 | `source.json` 的局内语言与[音频核对操作指南](local-asr.md) | 默认 `off`，按需启用；显式 `auto` 才是 `zh`/`en` 本地 Q8、`ja` 在线 Qwen。若本次要核对，在 TTS 前确认对应模型服务或项目 Qwen ASR 凭据可用；`off` 会跳过语义核对，不得标作通过 |
| 公共规则卡 | 游戏规则对象生成的 `ruleCard` | 画面摘录实际规则，不因模型一次误解而新增“纠错规则” |
| 样品选段文件（需要样品时） | 模型选择的真实 `sourceSeq` 和分段 | 覆盖待检查的流程与画面，明确节选而不冒充完整对局 |
| 封面素材与短标题 | 本局事实、`plan.cast`、当前人物图集与画面抽帧 | 选取真实冲突和对应人物，按 [封面制作](cover.md) 写好可复制提示词，使用 AI 生图工具生成并保存到 `output` |

## 第二阶段：整理人物与声音

使用现有角色图集和声音表；用户要求微调时，复用背景、人物、已成功音频和项目目录中的缓存。不要重新生成所有资产。

逐个对照 `plan.cast` 的名字、形象、角色设定与 `voices.profiles[voiceKey]`。声音应由人物决定，不按狼人/好人的临时身份更换。法官与上帝解说使用不同的固定声音；法官清楚、平稳，解说自然、口语化。12 个座位可以使用现有经过验证的不同音色，不用变速一个声音冒充多人。

主持短句也要听感自然。不要把“预言家请睁眼”拆字点读；整句连读，逗号只轻换气。当前声音表用 `judgeCues["seer-open"]` 为这句保留已试听确认的连读指令与 `rate: 1.14`，继续使用同一法官音色。其他主持句可按实际听感增加各自的 cue 配置，不因此改动玩家原话或全局声线。`project.ts` 的 `clipVoiceProfile` 只将此类指令／语速覆盖用于对应的法官流程片段；合成缓存仍以实际完整请求为准。用户指出听感问题时先生成短样音供试听，再替换对应片段；不能只核对字幕便声称已试听。

指令描述“年轻、冷静、句子干净、转折清晰”这类可执行特征，避免只写“自然好听”。核对服务支持的模型、音色、语速与指令字段。批量调用与新增服务适配器见 [批量 TTS](tts-batch.md)。

## 第三阶段：把自动模板改成真正的节目台词

首次写解说先按 [上帝解说写作步骤与可复制任务](commentary.md) 完成“读事实 → 列锚点 → 写开场／点评／收尾 → 写回 JSON → 逐句审核”。下面保留编辑格式和具体衔接说明，便于核对既有初稿。

### 先分清三种声音材料

1. **玩家原话**：公开发言、遗言和狼队密谈必须是该玩家通过 `speak` 或密谈工具实际提交的文字。完整片保留原话与顺序，样品保留选段原话。不得润色玩家的分析、纠正他的错误、补充理由、编造回答或模拟一段“更好”的发言。
2. **法官流程**：由 `hosting.ts` 补齐，负责叫醒/闭眼、询问行动、确认结果、邀请投票和宣布结果，不能拿点评替代。发言顺序只说起点与方向，不逐个念号码；警长回答后视频直接进入发言，法官不重复。结构化动作转成角色声音时标“行动转述”，不是伪装成原始发言。
3. **上帝解说**：需要你写，负责开场带入、解释已发生的关键反差和终局收束。使用 `commentator`，不替玩家编造动机，也不向玩家广播夜间秘密。

工具动作变成玩家声音的明确例子：法官问女巫是否用药 → 日志确认该玩家实际选择对 6 号使用解药 → 用该玩家固定音色说“我用解药救 6 号” → 法官确认后请闭眼。中间这句是对真实工具选择的固定模板口述，可以生成；“因为我觉得 6 号像好人所以救他”包含未记录理由，不能生成。查验、毒药、守护和方向选择同理。没有实际选择时不能替玩家选；系统托管标明来源，不能包装成模型自己的话。

`integrity.ts` 会在付费合成前核对玩家原话与实际朗读文字，并限制动作转述为已记录选择的固定模板。不要为让剧本顺畅而关闭它。

### 找这些位置增加话语

先看事实表和票型，把候选节点写成“锚点序号 → 已发生的事实 → 观众需要理解什么”，再写一两句。不是每条事件都要点评。

| 位置 | 先核对什么 | 可用表达方式 |
| --- | --- | --- |
| 开场 `game.start` | 板型、人物设定、视角 | 用一两句介绍这桌人物和看点，之后进入首夜；不提前报赢家 |
| 狼队密谈结束附近 | 这轮原话实际提出的计划 | 如计划有明确分工，可简短提示观众记住；没有记录的“早有预谋”不能写 |
| 警长投票结果之后 | 谁当选、真实阵营、票是否一致 | “警徽落在了狼队手里。”或用人物名字自然表达反差 |
| 首次关键放逐之后 | 被放逐者真实身份、已公布票数 | “真预言家第一天就走了，好人得回头找线索了。”不要提前报下一夜目标 |
| 用药/守护结算之后 | 目标、实际身份、是否生效 | “这瓶毒药命中了狼人。”不能仅看到守护目标就断言挡刀成功 |
| 警徽移交之后 | 警徽实际给谁、对方阵营 | “人走了，队友还接着带队。”不能预写下一任警长的归票 |
| 残局人数改变之后 | 当前存活集合、剩余狼数 | 简短交代压力和已知选择空间，不直接替观众锁定下一步 |
| 终局 `review` | 全部夜间行动、票型和胜负 | 选少数决定胜负的转折串成因果，不逐条重念整份复盘 |

表内句子是写法示例，不是通用事实。只有本局确实发生时才能使用。语气可以轻松，但避免堆“精彩博弈、局势瞬息万变”等空话。上帝点评通常一两句、约 3–10 秒即可，不插进同一玩家连续发言的分段之间。

开场和转场要与紧接着的实际环节相符；不需要额外预告下一角色。配音返回后，字幕仍使用审核过的朗读稿文字：提供方可能把同音字写错，不能把时间戳标签当成新文稿。查看 `caption-audit.json` 的差异清单，保持原字词时间不变；发现漏字、加字或语音内容不符时，先真实对齐/核对音频再继续。

### 写回准确的编辑格式

打开本项目的 `narration.json`，核对 `roomId`。`edits` 的键是原事件的 `sourceSeq`，不是视频秒数。原有编辑稿只作起点，不能直接套用另一局的座位和结论。

- 开场、终局解说等可用 `text` 替换该条法官材料，并设置 `voiceKey: "commentator"`。
- 投票、警徽等事实之后需要点评时，用 **`after`** 添加上帝话语。这样法官仍先完成播报，解说在结果之后出现。
- `reason` 说明编辑依据；`after` 内每句也写依据。不要给玩家发言的序号添加编辑，程序会拒绝。

下面是 **e6220f1238 这局的示例**；别的房间必须先查自己的事实与序号：

```json
{
  "roomId": "e6220f1238",
  "edits": {
    "2": {
      "voiceKey": "commentator",
      "text": "十二人预女猎守，上帝视角。开局先看这桌人的夜间选择。",
      "reason": "开场交代板型与视角，不提前给结局"
    },
    "36": {
      "reason": "保留法官的警长投票结果播报",
      "after": [
        {
          "text": "八张警下票，全部给到一号。警徽落在了狼队手里。",
          "reason": "本条结果已公布一号八票当选；身份表确认一号是狼人"
        }
      ]
    },
    "114": {
      "reason": "保留法官的警徽移交播报",
      "after": [
        {
          "text": "警徽给了四号。大老师人走了，队友还接着带队。",
          "reason": "本条已确认一号移交给四号；身份表确认两人同为狼人"
        }
      ]
    },
    "179": {
      "voiceKey": "commentator",
      "text": "回看这局，狼队开局拿到全部警下票，真预言家第一天就被放逐。第二夜女巫毒中九号，第二天一号出局。警徽虽然继续留在狼队手里，好人还是逐步找到了剩下的狼人。最后一夜，守卫挡住狼刀，好人最终完成逆转。",
      "reason": "终局按实际先后顺序收束关键转折"
    }
  }
}
```

`after` 由 `editorial.ts` 变成独立的解说片段，带唯一 ID 和原事实锚点；`hosting.ts` 先补法官流程，再接这些片段。不要靠把投票结果整条改成解说声音来实现同样效果。法官确认的夜间动作、投票与顺序会被流程层保留，旧编辑稿里的省略标记不能删掉它们。

### 润色完成后的自查

逐句查看新增开场/点评/收尾：

- 句子里每个人、身份、目标、票数和结果能否在本局材料里找到？
- 对过程点评，依据的事件是否都在锚点 `sourceSeq` 或以前？终局材料只能用来核对，不能提前泄露未来行动。
- 有没有把玩家声称“我验了谁”写成真的查验，或把计划写成已经执行？
- 有没有编造人物情绪、故意误导的动机或未记录的策略？有就删去或改成明确的不确定观察。
- 法官的完整流程是否仍在，解说是否只补理解、没有覆盖法官结果？
- 同一玩家的分段是否连续，原文与音色是否完整？

核对完成后在 `narration.json` 写入记录。`method` 按实际执行者使用 `model-editor` 或 `human-editor`；AI agent 可自行完成常规内部审核：

```json
"review": {
  "status": "reviewed",
  "method": "model-editor",
  "factsChecked": true,
  "playerQuotesUntouched": true,
  "futureResultsNotUsedInProcessCommentary": true,
  "notes": "已审核开场、关键点评与终局；法官流程完整保留"
}
```

这段记录描述已经完成的工作，不能在未读材料时先填。再次运行 `--prepare-only` 会刷新 `plan.json` 的审核状态；原编辑稿和音色文件会保留。显式指定 `--narration`、`--voices` 时，摘要和检查使用实际指定的文件。

## 第四阶段：备好画面与样品清单

完整上帝视角沿用现有背景、桌子和人物图集，检查它们与人物声音相符。右栏按本局实际身份生成完整技能卡，容纳不下时连续循环滚动，跨发言片段延续进度；不能长期固定只放预言家。单玩家视角只显示本人身份简介，其他座位保持未知，见[单玩家视角制作](player-view.md)。白天与黑夜同时切换顶栏、面板边框、中央卡、规则卡和字幕框。中央卡与波形较小，头像上的发言/上警/警徽更醒目。投票框随实际票型行数收紧，票源号码与票数放大，不能靠放大空框突出结果。这些样式由 `scene.ts`、`palette.ts`、`rule-cards.ts`、`rule-strip.ts` 和 `render.ts` 实现。

完整上帝视角底栏沿用整桌人物图集：左侧为 84px 人物头像，上行“编号 · 真实身份”，下行昵称；身份来自本局 cast，不随玩家冒认身份改变。单玩家视角只把自己的身份固定显示，其余席位始终为“身份未知”；授权可见的查验或密谈原话仍保留，不借终局 `review` 或 `knownIdentities` 改写身份标签。法官没有玩家席位，使用法槌徽记和“法官／流程主持”；上帝解说使用眼睛与星芒徽记和“上帝解说／全知视角”。两者占用相同位置，但徽记、标签与声线各自固定，不借用某一位玩家的头像。“行动转述／系统托管／狼队密谈”在身份行旁保留来源标记；出局玩家的遗言继续显示该玩家头像与实际出局状态。

字幕只占底栏右侧文字区，水平与垂直居中，不再在顶部另放发言者文字。1080p 当前底栏为 `(28,942,1864,111)`，文字区为 `(454,956,1410,83)`、中心 `(1159,998)`；头像与文字区由细线分开。`geometry.ts` 的 `subtitleLayout` 是场景与 ASS 共用坐标，`speaker.ts` 选择真实玩家或主持身份，`timeline.ts` 输出居中字幕。调整位置时同步这些模块，抽看最终编码后的画面，不能只看未烧字幕的底图。

完整上帝视角的画面样品优先覆盖长昵称与两位数编号的玩家、法官、上帝点评、昼夜两种主题和“行动转述”标记。需要共同评价画面时先交付带声音的独立样品，按用户反馈确定画面，再启动整局；制作整片时复用已确认的样品配音缓存。

用户只要样品时，先做独立目录和显式选择表，不先合成整局。选段应覆盖本次需要看的现象，例如夜间询问/选择/确认、上警标志、白天发言、警长决定顺序、投票邀请与结果；缺少的阶段不能用随便截取前五分钟代替。

选择表格式：

```json
{
  "description": "约五分钟修改样品；非连续节选",
  "sections": [
    { "title": "首夜流程", "sourceSeqs": [4, 6, 8, 16, 18, 19, 20] },
    { "title": "警长流程", "sourceSeqs": [36, 37, 39] },
    { "title": "玩家发言节选", "sourceSeqs": [41], "parts": { "41": [1] } },
    { "title": "放逐投票", "sourceSeqs": [65] }
  ]
}
```

此示例同样只属于 e6220f1238。程序按原顺序选段，保留所选玩家片段原文，并自动包含关联的法官流程。第一次只看实际音频时间轴，再按需要增减完整段；不要用假字幕时长凑五分钟。

```powershell
$env:VIDEO_ROOM = '实际房间ID'
$env:VIDEO_PROJECT_DIR = '本局制作目录下独立的样品目录绝对路径'
$env:VIDEO_NARRATION_FILE = '已润色的本局 narration.json 绝对路径'
node node_modules/tsx/dist/cli.mjs scripts/video/sample.ts --selection=样品选段文件路径
node node_modules/tsx/dist/cli.mjs scripts/video/synthesize.ts --prepared-clips
node node_modules/tsx/dist/cli.mjs scripts/video/audit-audio.ts --fail-on-error
node node_modules/tsx/dist/cli.mjs scripts/video/timeline.ts
node node_modules/tsx/dist/cli.mjs scripts/video/render.ts
node node_modules/tsx/dist/cli.mjs scripts/video/verify-sample.ts --video=样品目录/output/latest-match.mp4
```

原有整局存在时，`sample.ts` 按文字和角色复用配音；首次制作也可在准备完材料后选段，只为样品生成音频。完成样品后不要在同一 shell 忘记清掉 `VIDEO_PROJECT_DIR` 再跑整局；另开干净 shell 或显式设回正确目录。

## 第五阶段：启动自动化并验收

把 `ROOM_ID` 替换为准备时确定的房间号，先运行不调用 TTS 的材料检查：

```powershell
pnpm video:make --room=ROOM_ID --check-only --encoder=cpu
```

检查本局 `output/materials-check.json` 的 `ready` 和 `issues`。未通过时按缺项修改，不通过提前填写审核状态绕过。检查通过后，确认 TTS 的服务、账号和外发范围已有授权，再启动整片：

```powershell
pnpm video:make --room=ROOM_ID --resume
```

这两个命令默认使用本局目录的 `narration.json` 与 `voices.json`。使用独立制作目录或外部材料时，检查与正式制作均传入同样的 `--project-dir`、`--narration`、`--voices`。例如：

```powershell
pnpm video:make --room=ROOM_ID --project-dir=独立制作目录 --narration=本局旁白文件 --voices=本局声音表 --check-only --encoder=cpu
pnpm video:make --room=ROOM_ID --project-dir=独立制作目录 --narration=本局旁白文件 --voices=本局声音表 --encoder=auto --resume
```

之后程序完成合成、真实时间轴、直接小体积画面、预览和检查。没有 NVIDIA 或用户选择 CPU 时显式用 `--encoder=cpu`；强制 `gpu` 失败时不隐瞒回退。新版本可用 `--project-dir=独立目录` 保存，已有原片不覆盖。遇到鉴权/额度/审批失败，保留成功缓存并报告实际障碍，不重复请求或自动换付费服务。样品模式只跑样品，不暗中制作整局。

检查最终文件的夜间、白天发言、警长选择和投票帧，试听一个法官与一个人物；确认字清楚、标志不挡头像、投票结果不早于邀请、昼夜主题一致。默认交付 `output/latest-match.mp4` 小体积视频与字幕，说明实测时长、大小、是否节选和实际编码器；不主动生成大母版。内容已结束不代表允许上传公开平台，发布另按用户指示。

## 第六阶段：制作封面并整理发布材料

完整上帝视角对局默认还需一张带个性化短标题的封面。按 [封面制作](cover.md) 先写好 `output/cover-prompt.md`，整理本局人物和画面参考，再由 agent 调用 AI 生图工具或真人在生图产品中操作。生成后检查并保存 `output/cover.png`，补全制作记录。文档提供通用提示词模板、人工操作步骤与 Codex 的可选方法；已有确认版本时直接复用。单玩家视角不使用含全知身份或行动的封面；视频程序检查通过后仍要核对本视角的交付文件。

完整上帝视角的最终发布标题与简介写入同一制作目录下的 `output/publish-copy.md`，用 `# 标题`、`# 简介` 分开，交付时提供成片、封面和文案文件的链接。用户在聊天中调整用词后同步落盘，保留已经确认的措辞；备选标题不放进这份定稿。强调真人参局时按存档的座位控制方式核对，区分真人／AI操作与后期AI配音。单玩家视角不生成或复用此全桌发布文案。

完整上帝视角简介固定附上每席的座位、昵称、存档模型标识或“真人”，以及本局完整规则卡，不能只写板型名称或规则摘要。`plan.cast` 提供安全的控制方式／模型字段；真人优先于闲置的模型配置，未知模型明确标“未记录”，不猜版本。先在同一制作目录的 `output/publish-copy.md` 写好最终标题与简介，再同步本局座位表和规则卡。新 PowerShell 会话不会继承 `video:make --room=...` 子进程中的房间环境；运行 `video:publish-copy` 前显式设回本次的房间、数据目录和制作目录：

```powershell
$env:VIDEO_ROOM = 'ROOM_ID'
$env:VIDEO_DATA_DIR = (Resolve-Path 'data').Path # 使用 --data-dir 时改成相同的数据目录
$env:WEREWOLF_DATA = $env:VIDEO_DATA_DIR
$env:VIDEO_PROJECT_DIR = (Resolve-Path 'data/video/ROOM_ID').Path # 使用 --project-dir 时改成相同目录
pnpm video:publish-copy
```

输出中的 `roomId` 必须等于本次制作的房间 ID，`publicationUpdated` 应为 `true`；不匹配时停止，先纠正三个路径变量再运行，不能交付错房间文案。若提示缺少记录规则卡，重新导出并检查 `script.ruleCard`，不要凭印象补写。工具只更新有标记的座位表和规则卡段落，保留其他人工文案；规则来自 `script.ruleCard`，不拼接密钥、端点或整份座位配置。准备和整片验证阶段会同步已有文案；不会用占位标题冒充完成的发布稿。单玩家视角不运行此工具，也不输出其他席位名单、模型或规则卡。
