import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { projectDir, FPS, SAMPLE_RATE, ffprobe, type Script, type TimedClip } from './project';
import { replay } from './replay';
import { readPcm } from './audio';
import { assertPlayerSources, assertAuthorizedProject, assertPlayerAudio, assertPlayerVideo } from './integrity';
import { captionContent } from './timeline';
import { encodingSettings } from './encoding';
import { inspectAudio } from './audio-inspection';
import { assertTimelineAlignments } from './audio-alignment';

const source = JSON.parse(await readFile(`${projectDir}/source.json`, 'utf8')) as Script;
const script = JSON.parse(await readFile(`${projectDir}/script.json`, 'utf8')) as Script;
const timeline = JSON.parse(await readFile(`${projectDir}/timeline.json`, 'utf8')) as { frames: number; duration: number; clips: TimedClip[] };
await assertAuthorizedProject(timeline.clips);
await assertTimelineAlignments(timeline.clips, source.locale ?? 'zh-CN');
const masterSha256 = await assertPlayerAudio(timeline.clips);
assert.deepEqual(script.events, source.events, 'Editorial changed the game facts');
assertPlayerSources(source, script, timeline.clips);
const sourcePlayers = source.chapters.flatMap((c) => c.entries).filter((e) => e.seat !== undefined);
for (const e of sourcePlayers) {
  const chunks = timeline.clips.filter((c) => c.sourceSeq === e.sourceSeq && !c.data.presentationOnly);
  assert(chunks.length > 0);
  assert.equal(chunks.map((c) => c.text).join('').replace(/\s/g, ''), e.text.replace(/\s/g, ''), `Changed player speech at ${e.sourceSeq}`);
  assert(chunks.every((c) => c.voiceKey === e.voiceKey && c.seat === e.seat));
}
const final = replay(source, Number.MAX_SAFE_INTEGER), review = source.events.findLast((e) => e.type === 'review');
if (source.perspective === 'god') {
  assert(review, 'Missing recorded end review');
  assert.deepEqual([...final.alive].sort((a, b) => a - b), review.data.roles.filter((r: any) => r.alive).map((r: any) => r.seat).sort((a: number, b: number) => a - b));
} else {
  assert(!review && !source.ruleCard && source.cast.every((c) => c.seat === source.playerSeat || c.role === 'unknown'), 'Player view contains privileged material');
  assert(source.events.every((e) => e.audience === 'public' || e.audience.includes(source.playerSeat!)), 'Player view contains an unauthorized event');
}
assert.equal(final.result.winner, source.result.winner);
let cursor = 0, captions = 0;
const actualEncoders = new Set<string>(), settings = encodingSettings();
let compactFromFirstEncode = true;
for (const c of timeline.clips) {
  const originalAudio = await readPcm(c.audioFile);
  assert.equal(inspectAudio(originalAudio.samples, originalAudio.sampleRate).issues.length, 0, `Audio waveform defects in ${c.id}; run video:audit-audio and video:repair-audio`);
  assert.equal(c.startFrame, cursor); cursor += c.frames;
  assert(c.captions.length && c.audioMeta.text === c.spokenText);
  assert.equal(captionContent(c.captions.map((cue) => cue.text).join('')), captionContent(c.spokenText), `Caption spelling differs from script: ${c.id}`);
  for (const cue of c.captions) assert(cue.start >= 0 && cue.end > cue.start && cue.end <= c.audioDuration + .001);
  const pcm = await readPcm(`${projectDir}/audio-normalized/${c.id}.wav`);
  assert.equal(pcm.sampleRate, SAMPLE_RATE); assert.equal(pcm.samples.length, c.frames * SAMPLE_RATE / FPS);
  const segment = JSON.parse(await readFile(`${projectDir}/segments/${c.id}.mp4.json`, 'utf8'));
  assert.equal(segment.frames, c.frames); actualEncoders.add(segment.encoder);
  compactFromFirstEncode &&= segment.encoding?.format === 'native-compact-v1';
  if (settings.strictGpu) assert.equal(segment.encoder, 'h264_nvenc', `GPU encoding was not used for ${c.id}`);
  const log = await readFile(`${projectDir}/segments/${c.id}.mp4.log`, 'utf8');
  assert(!/corrupt|invalid data|error while/i.test(log), `Encoding problem in ${c.id}`);
  captions += c.captions.length;
}
assert.equal(cursor, timeline.frames);
const video = `${projectDir}/output/latest-match.mp4`;
await assertPlayerVideo(source, video, masterSha256);
const media = JSON.parse(execFileSync(ffprobe, ['-v', 'error', '-show_streams', '-show_format', '-show_chapters', '-of', 'json', video], { encoding: 'utf8', windowsHide: true }));
const picture = media.streams.find((s: any) => s.codec_type === 'video'), audio = media.streams.find((s: any) => s.codec_type === 'audio');
assert.equal(picture.width, 1920); assert.equal(picture.height, 1080); assert.equal(picture.r_frame_rate, '30/1');
assert.equal(Number(picture.nb_frames), timeline.frames); assert.equal(audio.codec_name, 'aac');
assert(Math.abs(Number(picture.duration) - timeline.duration) < 1 / FPS);
assert(Math.abs(Number(audio.duration) - timeline.duration) < .05);
assert.equal(media.chapters.length, source.chapters.length);
const report = { roomId: source.roomId, video, bytes: (await stat(video)).size, durationSeconds: timeline.duration, frames: timeline.frames,
  resolution: '1920×1080', fps: FPS, chapters: media.chapters.length, clips: timeline.clips.length, captions,
  originalPlayerEntriesPreserved: sourcePlayers.length, privateWolfChatIncluded: source.events.some((e) => e.type === 'wolf.chat'), perspective: source.perspective, playerSeat: source.playerSeat, factsUnchanged: true,
  validationScope: 'script-and-timing-only', audioSemanticReview: 'not-checked', voiceIdentityReview: 'not-checked',
  timestampSources: [...new Set(timeline.clips.map((clip) => clip.captionAlignment ? `external-transcript:${clip.captionAlignment.engine}` : 'provider'))],
  finalAliveSeats: [...final.alive], winner: final.result.winnerName, audioVideoDifferenceSeconds: Math.abs(Number(picture.duration) - Number(audio.duration)),
  voices: [...new Set(timeline.clips.map((c) => c.audioMeta.voice))].length,
  audioWaveformAuditPassed: true,
  videoCodec: picture.codec_name, encoders: [...actualEncoders], compactFromFirstEncode,
  averageTotalKbps: Number(((await stat(video)).size * 8 / timeline.duration / 1000).toFixed(1)) };
await writeFile(`${projectDir}/output/verification.json`, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
